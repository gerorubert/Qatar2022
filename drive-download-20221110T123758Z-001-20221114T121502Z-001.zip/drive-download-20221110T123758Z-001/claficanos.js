function correcto(){
    alert("¡Su respuesta se envió correctamente!")
}

function gracias(){
    alert("¡Gracias por tu respuesta!")
}